import React from 'react';

// Simple card component used in combat. Displays the card name and description
// and calls onPlay when clicked.
export default function Card({ card, onPlay }) {
  return (
    <div className="card" onClick={() => onPlay(card)}>
      <h4>{card.name}</h4>
      <p>{card.description}</p>
    </div>
  );
}