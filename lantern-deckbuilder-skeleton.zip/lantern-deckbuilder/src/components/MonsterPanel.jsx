import React from 'react';

// Displays monster information during a fight. Shows HP and the next intent.
export default function MonsterPanel({ monster }) {
  return (
    <div className="monster-panel">
      <h2>{monster.name}</h2>
      <p>HP: {monster.hp}</p>
      <p>Next Intent: [placeholder]</p>
    </div>
  );
}