// Placeholder combat logic functions. These functions will later handle
// card effects, damage calculation, bleeding, etc.

export function playCard(card, state) {
  // Apply the effect of a card. In a real implementation this would
  // update survivor stats, monster HP and deck piles.
  return state;
}

export function applyMonsterIntent(monster, state) {
  // Apply the monster's current intent to the survivor state.
  return state;
}