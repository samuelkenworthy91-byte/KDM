// Placeholder deck management functions. These will eventually handle
// drawing, shuffling, discarding and exhausting cards.

export function drawCards(deck, hand, discard, num) {
  // Draw num cards from the deck into the hand. If the deck is
  // exhausted, shuffle the discard pile back in.
  return { deck, hand, discard };
}

export function discardCard(hand, discard, cardIndex) {
  // Discard the card at cardIndex from the hand into the discard pile.
  return { hand, discard };
}